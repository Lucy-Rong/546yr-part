const express = require('express')
const router = express.Router()
const { createUser } = require('../data/users')
const { checkUser } = require('../data/users')


// router.get("/", (req, res) => {
//     try {
//         let authenticated = true;
//         if (!req.session.user) {
//             authenticated = false;
//         }
//         res.render("layouts/mainpage");
//     } catch (error) {
//         res.status(404).json({ message: "Page not found" });
//     }
// });
router.get('/', async(req, res) => {
    try {
        if (req.session.user) {
            res.redirect("/mainpage");
        } else {
            res.redirect("/logsign");
        }
    } catch (e) {
        res.render("posts/error", { error: e });
        return;
    }
});

router.get("/logsign", async(req, res) => {
    try {
        res.render("pages/users/logsign");
        return;
    } catch (e) {
        res.status(404).json({ error: "Internal Error" });
        return;
    }
})


router.post('/logsign', async(req, res) => {
    if ('signup' === req.body.formType) {
        let userInfo = req.body;
        try {
            const newUser = await createUser(
                userInfo.firstName,
                userInfo.lastName,
                userInfo.username,
                userInfo.email,
                userInfo.password
            );
            res.redirect("users/logsign");
        } catch (e) {
            console.log(e);
            res.render("pages/users/logsign");
            return;
        }
    } else if ('login' === req.body.formType) {
        try {
            let userInfo = req.body;
            let user = await checkUser(userInfo.username, userInfo.password);
            req.session.user = { username: user.username.toLowerCase(), userId: user._id.toString() };
            return res.json("success");
        } catch (e) {
            console.log(e);
            return res.status(400).json({ error: e });
        }
    }
})


router.get('/logout', async(req, res) => {
    req.session.destroy();
    res.redirect("/users/logsign");
})


module.exports = router