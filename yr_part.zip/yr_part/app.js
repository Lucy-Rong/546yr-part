const express = require('express');
const app = express();
const session = require('express-session');
const static = express.static(__dirname + '/public');
const configRoutes = require('./routes');
const exphbs = require("express-handlebars");

var bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


// const handlebarsInstance = exphbs.create({
//     defaultLayout: 'mainpage',
//     // Specify helpers which are only registered on this instance.
//     helpers: {
//         asJSON: (obj, spacing) => {
//             if (typeof spacing === 'number')
//                 return new Handlebars.SafeString(JSON.stringify(obj, null, spacing));

//             return new Handlebars.SafeString(JSON.stringify(obj));
//         }
//     },

//     partialsDir: ['views/partials/']
// });


app.use(express.json());
app.use('/public', static);
app.use(express.urlencoded({ extended: true }));
app.engine("handlebars", exphbs.engine({ defaultLayout: "mainpage" }));
//app.engine("handlebars", handlebarsInstance.engine);
app.set('view engine', 'handlebars');

app.use(session({
    name: 'AuthCookie',
    secret: 'some secret string!',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 24 * 60 * 60 * 1000 },
}));


app.use(function(req, res, next) {
    userStatus = !req.session.user ?
        "Non-Authenticated User" :
        "Authenticated User";
    console.log(
        "[" +
        new Date().toUTCString() +
        "]:" +
        " " +
        req.method +
        " " +
        req.originalUrl +
        " (" +
        userStatus +
        ")"
    );
    next();
});

app.use("/", (req, res, next) => {
    if (!req.session.user && !req.url == "/logsign") {
        res.redirect("/logsign");
        return;
    }
    next();
});

app.use("/", (req, res, next) => {
    if (req.session.user && req.url == "/logsign") {
        res.redirect("/mainpage");
        return;
    }
    next();
});


// app.use('layouts/mainpage', (req, res, next) => {
//     if (!req.session.user) {
//         res.status(403).render("user/error", { error: "User not logged in" });
//         res.redirect("/users/logsign");
//     } else {
//         next();
//     }
// });
// app.use('users/logsign', (req, res, next) => {
//     if ('login' === req.body.formType) {
//         if (req.session.user) {
//             return res.redirect('/layouts/mainpage');
//         } else {
//             req.method = 'POST';
//             next();
//         }
//     }
// });


configRoutes(app);

app.listen(3000, () => {
    console.log("We've now got a server!");
    console.log('Your routes will be running on http://localhost:3000');
});